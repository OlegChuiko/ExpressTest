document.getElementById('close_my_modal_btn').addEventListener('click', function() {
    var modal = document.querySelector('.popup2');
    modal.style.display = 'none';
});